---
name: analyze-code-backed-requirement
description: Analyze business requirements with mandatory code evidence. Use when a user asks Codex to evaluate a demand, meeting note, AI transcript, PRD, PDF, or text-based business request and produce requirement background, goals, feasibility, system gaps, and clarification questions by combining the requirement input with a Yunxiao/Codeup repository or local codebase. Trigger for Chinese or English requests about "需求分析", "需求澄清", "可行性评估", "结合代码看需求", "AI听记会议纪要", "业务提需", or similar product-management analysis tasks.
---

# Analyze Code Backed Requirement

## Core Rule

Do not produce the final requirement analysis until both inputs are available:

1. Clear business requirement content.
2. Relevant system code from a confirmed repository or a local codebase.

If either input is missing, stop and ask for the missing input. Do not fill gaps with generic product advice.

## Workflow

### 1. Validate Business Requirement Input

First check whether the user provided usable business requirement content:

- Meeting minutes, AI transcript, PDF, DOCX, Markdown, plain text, screenshot text, or pasted conversation.
- A clear product request, pain point, target workflow, or business scenario.

If no usable requirement content is present, ask the user to provide it and stop.

If a file is provided:

- Use the appropriate file skill/tool to extract text.
- Preserve original files.
- If extraction fails or the content is unreadable, ask for a readable file or pasted text and stop.

After reading the content, summarize the request in 3-6 bullets before looking for code. Use this summary to identify likely systems, modules, business nouns, page names, API names, and data entities.

### 2. Confirm the Code Source

Check for an explicit code source:

- A named Yunxiao/Codeup repository.
- A local repository path.
- Existing project files in the workspace that clearly form the target system codebase.

If a local codebase is available, inspect it with `rg --files`, `rg`, and repository metadata before using it.

If the user did not specify a repository and no local codebase is available:

1. Search available tools for Yunxiao/Codeup MCP access, usually with `tool_search` using terms such as `codeup`, `yunxiao`, or `repository`.
2. Use the repository search/list tool to find candidate repositories based on requirement keywords, system names, module names, and business nouns.
3. Send the candidate repository name(s) to the user and ask for confirmation.
4. If multiple candidates exist, ask the user to choose.
5. Stop until the repository is confirmed.

If Yunxiao/Codeup MCP is unavailable and no local codebase exists:

- Try to discover or enable the relevant MCP/tool if the environment supports it.
- If code still cannot be reached, stop and explain that code-backed analysis cannot proceed without repository access.

Use the repository default branch. If the MCP does not expose a default branch directly, infer cautiously from branch metadata and repo config, preferring an explicit default indicator, then `main`, then `master`. If branch choice is ambiguous, state the ambiguity and ask.

### 3. Read Relevant Code Completely

Do not rely on filenames alone. Trace the requirement through the codebase:

1. Entry points: controller, route, page, API, command, scheduled job, or export/import endpoint.
2. Service layer: business orchestration, validation, state transitions, permission checks.
3. Data layer: mapper, repository, SQL, ORM model, entity, enum, dictionary, config.
4. Templates/assets: Excel, PDF, email, report, OSS/static templates, frontend forms.
5. Cross-module dependencies: Feign/RPC clients, shared packages, downstream services.

Read full relevant files or complete relevant methods/classes. If a file is too large, inspect the complete method/class region plus all referenced methods needed to understand behavior.

For Yunxiao/Codeup MCP, use the available repo, branch, tree/search, and file-read tools. For local repositories, prefer `rg` and targeted file reads.

Record code evidence while reading:

- Repository, branch, and module.
- File paths and key functions/classes.
- Existing behavior.
- Missing behavior.
- Risky assumptions.

### 4. Assess Feasibility

Base feasibility on code evidence:

- Existing capabilities that can be reused.
- Required backend/frontend/data/template changes.
- State, permission, data source, formula, and integration risks.
- Whether the request is a configuration/template change, small feature, medium feature, or larger redesign.
- Most likely implementation path and MVP boundary.

If code contradicts the business assumption, state the contradiction directly.

### 5. Draft the Report

When generating the final Markdown report, read `references/report-template.md` and follow its structure.

Required output sections:

1. Requirement overview.
2. Requirement background and goals.
3. Code-backed feasibility assessment.
4. Code evidence.
5. Clarification questionnaire.
6. Recommended MVP boundary.
7. Initial acceptance criteria.

Clarification questions must be actionable:

- Split questions into system-logic questions and business-logic questions.
- Avoid yes/no questions.
- For each question, provide 2-3 mutually exclusive options such as `[A]`, `[B]`, `[C]`.
- Tie questions to actual code gaps, data ambiguity, business rule ambiguity, or implementation risk.

When working in a workspace, save the report under `outputs/` with a clear filename such as:

`outputs/<需求名称>_需求分析_基于代码.md`

## Stop Conditions

Stop and ask for input when:

- No business requirement content is available.
- Requirement content is unreadable.
- No confirmed repository or local codebase is available.
- Yunxiao/Codeup MCP is unreachable and no local code exists.
- Multiple repositories are plausible and the user has not chosen one.
- The relevant code cannot be read enough to support a code-backed conclusion.

## Quality Bar

The final analysis must make clear which conclusions come from business input and which come from code.

Do not:

- Produce generic PM templates without code evidence.
- Claim a system supports a behavior unless the code proves it.
- Ignore repository confirmation when the repo was inferred.
- Skip data models, status enums, formulas, permissions, or templates when they are relevant to the requirement.
- Treat meeting statements as final system truth when code suggests a different implementation.
